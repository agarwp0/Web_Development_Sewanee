//  USING JQUERY

// Align instructions properly according to the height of infographic

$(document).ready(
  function(){
    var height = $('#careerpath').height();
    $('#instructions').css({ 'padding-top': height });
  }
);


//Executes when the window is resized
$(window).resize(function() {
  var h = $('#careerpath').height();
  $('#instructions').css({ 'padding-top': h });
});

// -----------------------------------------------------------------------

// toggle the images based on area clicks
$(document).ready(
  function(){
    $('.areas').click(
      function(event){
        $areaId=event.target.id.slice(-2);
        $pathId=$("#path"+$areaId);
        $('.paths').hide();
        $pathId.show();
      }
    );
  }
);


// -----------------------------------------------------------------------
